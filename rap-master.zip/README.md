# rpa

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).

{
    city: ""
country: ""
headimgurl: "https://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLgKPdpx4Yic1prMBmGAibmQOGGW1WXGAGTMMBNU9n1sxZoVxh0V4ca35ViaBtpUPPpPTUI5beTst68Q/132"
language: ""
nickname: "@mystart"
openid: "oCZ8s5jXxRdbEqkfpE3VZV8tYfKo"
privilege: []
province: ""
sex: 0
}

 {
          "id": 1,
          "commentId": 1,
          "replyId": 1,
          "replyType": "comment",
          "content": "别傻啦",
          "fromUid": "ozNrn6cEspMN0Yee_YDo-hTZ12gg",
          "toUid": "ozNrn6XnlOPVTwjdcWufv6wyrPPc",
          "fromNickname": "月迹",
          "toNickname": "@mysatrt",
          "url": "https://thirdwx.qlogo.cn/mmopen/vi_32/u954UKCTyyHep0fRfQJAjSurPebtLbZu40XQDLQRolyick2aQewTb1O5aJoTTF250XJfXksgLwnIPOibAflic6baQ/132"
        },


        {
  "commentId": 19,
  "content": "试一试",
  "fromNickname": "吃一口咸",
  "fromUid": "ozNrn6W2Yzy3RfBEYtZ3GdiUj35A",
  "id": 0,
  "replyId": 36,
  "replyType": "reply",
  "toNickname": "吃一口咸",
  "toUid": "ozNrn6W2Yzy3RfBEYtZ3GdiUj35A",
  "url": "https://thirdwx.qlogo.cn/mmopen/vi_32/DYAIOgq83epPYkSkbDSnYefiaiaBLW86msYmUjk4JRwI2bZZJeff9AFVrPbBEJpftFiaAYNhpFVDZxImkItcAbQfQ/132"
}