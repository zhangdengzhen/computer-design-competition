<template>
  <div>
    <van-cell
      v-for="(item, index) in list"
      :key="index"
      :value="item.title"
      :url="item.url"
    />
  </div>
</template>
<script>
import axios from "axios";
export default {
  data() {
    return {
      type: null,
      list: [],
    };
  },
  created() {
    console.log(this.$route.params.type);
    this.type = this.$route.params.type;
    axios({
      method: "GET",
      url: "http://106.14.145.57:7788/api/v1/workInformationUseSchoolName",
      params: { SchoolName: this.type },
    }).then((e) => {
      console.log(e.data.data);
      this.list = [];

        this.list = e.data.data;
      
    });
  },
};
</script>